# Joshua Talgham Cohen — AI Literacy Portfolio

A responsive static website for Joshua's Grade 12 AI Literacy Portfolio at Magen David Academy. It uses plain HTML, CSS, and JavaScript, with no build tools or backend.

## Files

- `index.html` — website content and project links
- `style.css` — layout, colors, responsive styles, and animations
- `script.js` — mobile navigation, scroll reveals, and active navigation state
- `assets/` — add your own images here

## Preview locally

Open `index.html` in a web browser. The site does not require installation or a server.

## Add the portfolio images

1. Put Joshua's profile photo in `assets/` and name it `profile.jpg`.
2. In `index.html`, find the comment marked `PROFILE IMAGE`.
3. Replace the profile placeholder `<div class="profile-placeholder" ...>` with:
   ```html
   <img class="profile-photo" src="assets/profile.jpg" alt="Portrait of Joshua Talgham Cohen">
   ```
4. Add the AI-generated project image as `assets/ai-image.jpg`.
5. In `index.html`, find the comment marked `To display the project image` and replace the `.upload-area` with:
   ```html
   <img class="project-upload-image" src="assets/ai-image.jpg" alt="AI-generated person created for the AI Image project">
   ```
6. If you use a different image format or filename, update the `src` value. The website works without these optional photos; it shows designed placeholders instead of broken image icons.

## Publish with GitHub Pages

1. Sign in to GitHub and create a new repository, for example `joshua-ai-literacy-portfolio`.
2. Upload **all** the files and folders in this project. Keep `index.html`, `style.css`, `script.js`, and `README.md` at the repository's top level, and include the `assets` folder.
3. In the repository, open **Settings**.
4. Select **Pages** in the left sidebar.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Choose the `main` branch and `/ (root)` folder, then click **Save**.
7. Wait a few minutes. GitHub will show the public website URL in the Pages settings, usually `https://YOUR-USERNAME.github.io/joshua-ai-literacy-portfolio/`.
8. Open that URL in a private/incognito window or on a phone to confirm that the site is public and responsive. Your teacher does not need repository edit access or a GitHub account to view a public Pages site.

## Before submitting

- Check each project button opens the correct external page in a new tab.
- Add the profile and AI-generated image if available.
- Test the mobile menu and all navigation links.
- Confirm the repository is **public** if your teacher needs to access the site without logging in.
